const sql = require('./conn');

const emptyOrRows = function(rows) {
  if (!rows) {
    return [];
  }
  return rows;
}

// Get Data from database
async function getAccountNames(){

  sql.connect(function(err) {
    if (err) {
        console.error('Error connecting: ' + err.stack);
        return;
    }  
  });
  const cols = await sql.query('SELECT Account FROM policy;', function (error, results, fields) {
    if (error) throw error;
    results.forEach(result => {
        console.log(result);
    });
  });
  const dataSet = emptyOrRows(cols);

  return dataSet;
  // sql.end();
}

module.exports = {
  getAccountNames
}